import React, { useState } from 'react'
import styles from './Home2.module.sass'
import { useNavigate } from 'react-router-dom';
import {IoIosArrowForward, IoMdWallet} from 'react-icons/io'

export default function Home2() {
  let navigate = useNavigate();
  const [account, setAccount] = useState(false)
 const handleNavigate = () => {
  navigate('/exchange')
 }
 const walletConnectionHandler = () => {
  alert("walletConnectionHandler")
 }
  return (
    <div className={styles.background}>
    <h1>Exchange Name</h1>
    {
      account ? 
      <>
        <button onClick={walletConnectionHandler} className={styles.btnGrad}>Connect Wallet <IoMdWallet style={{marginLeft:"10px"}}/></button>
      </>
      :
      <>
      <button onClick={handleNavigate} className={styles.btnGrad}>Use Exchange <IoIosArrowForward/></button>
      </>
    }
    
    
    </div>
  )
}
