import React,{useState} from 'react'
import styles from './Card2.module.sass'
import Dropdown from '../DropDown'
import Dropdown2 from '../Dropdown2'
export default function Card2({isDisabled,value,send,func}) {
  const [amount, setAmount] = useState(0);
  const chains = [
    {
      logo: './polygon.png',
      title: 'Polygon'
    },
    {
      logo: './bsc.png',
      title: 'Binance Smart Chain'
    },
  ]
  return (
    <div className={styles.background}>
      <div className={styles.upper}>
        <p>{send}</p>
        <p>Balance: 0</p>
      </div>
      <div className={styles.lower}>
        <Dropdown2 chains={chains}/>
        <div>
        <input value={value} type="text" placeholder='0.00' disabled={isDisabled} onChange={event => func(event.target.value)}/>
        <p>ETH</p>
        </div>
      </div>
    </div>
  )
}
