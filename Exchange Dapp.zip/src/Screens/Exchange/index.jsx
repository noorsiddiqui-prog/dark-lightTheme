import React,{useState} from 'react'
import styles from './Exchange.module.sass'
import Card2 from '../../Components/Card2'
export default function Exchange() {
  const [outputValue, setOutputValue] = useState()
  function pull_val(val){
    setOutputValue(val);
  }
  
  return (
    <div className={styles.background}>
      <h1>Exchange Name</h1>
        <Card2 func={pull_val} send='From'/>
        <br/>
        <Card2 send='To' isDisabled={true} value={outputValue}/>
        <div className={styles.feesContainer}>
          <div className={styles.upper}>
            <p>Fees</p>
            <p>0.00 ETH</p>
          </div>
          <div className={styles.lower}>
            <p className={styles.estimate}>Estimated Recieved</p>
            <p className={styles.estimate}>{outputValue ? outputValue : '0.00'} ETH</p>
          </div>
        </div>
    </div>
  )
}
