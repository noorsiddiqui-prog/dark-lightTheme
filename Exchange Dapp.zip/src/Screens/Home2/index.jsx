import React from 'react'
import styles from './Home2.module.sass'
import { useNavigate } from 'react-router-dom';
import {IoIosArrowForward} from 'react-icons/io'
export default function Home2() {
  let navigate = useNavigate();
 const handleNavigate = () => {
  navigate('/exchange')
 }
  return (
    <div className={styles.background}>
    <h1>Exchange Name</h1>
    <button onClick={handleNavigate} className={styles.btnGrad}>Use Exchange <IoIosArrowForward/></button>
    </div>
  )
}
