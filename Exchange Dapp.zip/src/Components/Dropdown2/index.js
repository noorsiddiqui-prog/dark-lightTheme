import * as React from "react";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormHelperText from "@mui/material/FormHelperText";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import Box from "@mui/material/Box";
export default function SelectLabels({ chains }) {
  const [chain, setChain] = React.useState("");

  const handleChange = (event) => {
    setChain(event.target.value);
  };
  return (
    <div>
      <FormControl sx={{ m: 1, minWidth: 120 }}>
        <Select
          value={chain}
          onChange={handleChange}
          displayEmpty
          inputProps={{ "aria-label": "Without label" }}
          autoWidth={true}
        >
          <MenuItem value="">
            <Box>
              <img
                src="./ethereum.png"
                alt="avatar"
                style={{ width: "20px", height: "20px" }}
              />
            </Box>
            Ethereum
          </MenuItem>
          {chains.map((v, i) => {
            return (
              <MenuItem value={i}>
                <Box>
                  <img
                    src={v?.logo}
                    alt="avatar"
                    style={{
                      width: "20px",
                      height: "20px",
                      marginRight: "5px",
                    }}
                  />
                </Box>
                {v?.title}
              </MenuItem>
            );
          })}
          {/* <MenuItem value={20}>
            <Box>
              <img
                src="./ethereum.png"
                alt="avatar"
                style={{ width: "20px", height: "20px" }}
              />
            </Box>
            Ethereum
          </MenuItem>
          <MenuItem value={30}>
            <Box>
              <img
                src="./bsc.png"
                alt="avatar"
                style={{ width: "20px", height: "20px" }}
              />
            </Box>
            Binance Smart Chain
          </MenuItem> */}
        </Select>
      </FormControl>
    </div>
  );
}
