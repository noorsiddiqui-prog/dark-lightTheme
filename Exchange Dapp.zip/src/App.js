import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
// import Card from "./Components/Card/Card";
// import Home from "./Screens/Home";
import Home2 from "./Screens/Home2";
import Exchange from "./Screens/Exchange";
function App() {
  return (
    <>
      {/* <Home />; */}
      {/* <Home2 /> */}
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home2 />} />
          <Route path="exchange" element={<Exchange />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
